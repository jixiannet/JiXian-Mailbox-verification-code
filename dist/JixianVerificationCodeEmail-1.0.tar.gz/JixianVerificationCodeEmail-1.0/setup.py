from setuptools import setup

setup(
    name='JixianVerificationCodeEmail',
    version='1.0',
    packages=['JixianVerificationCodeEmail'],
    url='https://www.jixiannet.com',
    license='',
    author='Moxin',
    author_email='lqn@jixiannet.com',
    description='即现验证码邮箱版'
)

